package br.edu.ifsul.ws.restful;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/app")        
public class RestApp extends Application {
    
}
