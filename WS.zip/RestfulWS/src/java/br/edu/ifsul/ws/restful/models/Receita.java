package br.edu.ifsul.ws.restful.models;

import java.util.List;

/**
 *
 * @author paulosouza
 */
public class Receita {
    private int id;
    private String nome;
    private String descricao;
    private List<Ingrediente> ingredientes;
    
    
}
